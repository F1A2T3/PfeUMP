<?php 
  //  include("connection.php");
//
//
  //  if(isset($_POST['update'])){
  //      $nom_equipe=$_POST['nom_equipe'];
  //      $
  //  }
?>