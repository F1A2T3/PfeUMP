<?php
$i = 0;
$a = 5;
if($i == 0)
   $a = 6;
else
   $a = 9; 
echo "a=".$a;
?>