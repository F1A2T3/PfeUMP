<?php
function print_r2($tab){
    echo "<pre>";
    print_r($tab);
    echo "</pre>";
} ?>