<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Document</title>
</head>
<body>
<input type="datetime-local" name="date_heure" />

</body>
</html>
Extraire la date du jour entrer
// jour de la semaine entré par l'utilisateur
$jourSemaine = "mardi";

// date courante
$dateCourante = date("Y-m-d");

// date du jour de la semaine entré par l'utilisateur dans la semaine courante
$dateJourSemaine = date("Y-m-d", strtotime("this week $jourSemaine", strtotime($dateCourante)));

echo $dateJourSemaine;





Extraire de la base de donnees
// Extraction de la date YYYY/MM/DD
$date = date('Y/m/d', strtotime($temp_debut));

// Extraction de l'heure de début
$heure_debut = date('H:i:s', strtotime($temp_debut));

// Extraction de l'heure de fin en ajoutant 1 heure à l'heure de début
$heure_fin = date('H:i:s', strtotime('+1 hour', strtotime($heure_debut)));





Extraire le jour de la date dans base de donnees
$date = '2022-06-10'; // Exemple de date
$jourSemaine = strftime('%A', strtotime($date)); // Récupération du jour de la semaine
echo $jourSemaine; // Affichage du jour de la semaine (en français : vendredi)





Update table
// Concaténer date et heure pour former la valeur à insérer dans la colonne
$temp_debut = date('Y-m-d H:i:s', strtotime("$date $heure_debut"));

// Faire l'update de la colonne temp_debut
$sql = "UPDATE matchclub SET temp_debut = '$temp_debut' WHERE id_match = $id_match";
$result = mysqli_query($conn, $sql);













// Sélection de toutes les lignes avec etat = "fixe"
$stmt = $bdd->prepare("SELECT * FROM matchclub WHERE statut = 'fixe'");
$stmt->execute();

// Traitement sur chaque ligne sélectionnée
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    // Extraction de la date et de l'heure de début et fin
    $date = date('Y-m-d', strtotime($row['temp_debut']));
    $heure_debut = date('H:i:s', strtotime($row['temp_debut']));
    $heure_fin = date('H:i:s', strtotime($row['temp_fin']));
    $jourSemaine = strftime('%A', strtotime($date)); // Récupération du jour de la semaine
    $dateCourante = date("Y-m-d");

    // date du jour de la semaine entré par l'utilisateur dans la semaine courante
    $dateJourSemaine = date("Y-m-d", strtotime("this week $jourSemaine", strtotime($dateCourante)));
    // Mise à jour de la colonne temp_debut et temp_fin avec la nouvelle date et heure
    $stmt2 = $dbh->prepare("UPDATE matchclub SET temp_debut = :new_date_debut, temp_fin = :new_date_fin WHERE id_match = :id");
    $stmt2->bindParam(':new_date_debut', $dateJourSemaine . " " . $heure_debut);
    $stmt2->bindParam(':new_date_fin', $dateJourSemaine . " " . $heure_fin);
    $stmt2->bindParam(':id', $row['id_match']);
    $stmt2->execute();
}