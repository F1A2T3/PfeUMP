<!-- <?php
// $i = 0;
// $a = 5;
// if($i == 0)
//    $a = 6;
// else
//    $a = 9; 
// echo "a=".$a;
?> -->








<!-- // table des dates de format yyyy-mm-dd
$table_dates = array('2023-05-01', '2023-05-02', '2023-05-03');

// heure de début
$heure_debut = '14:30';

// nouveau tableau pour les dates et heures de début concaténées
$dates_debut = array();

// boucle pour concaténer les dates et les heures de début
foreach($table_dates as $date) {
    $datetime_str = $date . ' ' . $heure_debut;
    $datetime = new DateTime($datetime_str);
    $dates_debut[] = $datetime->format('Y-m-d H:i:s');
}

// Afficher les valeurs de dates_debut pour vérification
var_dump($dates_debut); -->



<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Document</title>
</head>
<body>
<?php
$debut_time = "04:20:00";
?>

<input type="time" name="heure_debut" id="date_debut_input" required value="<?= $debut_time ?>">
</body>
</html>







































































// Fonction pour récupérer les données du match depuis la base de données
function getMatchData(matchId) {
  // Effectuer une requête AJAX vers votre script PHP
  var xhr = new XMLHttpRequest();
  xhr.open('GET', 'votre_script_php.php?id_match=' + matchId, true);

  xhr.onload = function() {
    if (xhr.status === 200) {
      var matchData = JSON.parse(xhr.responseText);

      // Utiliser les données du match pour initialiser le formulaire de modification
      document.getElementById('team1').value = matchData.team1;
      document.getElementById('team2').value = matchData.team2;
      // Autres champs de formulaire avec les données correspondantes
    }
  };

  xhr.send();
}






























<?php
$matchId = $_GET['id_match'];

// Effectuer la requête SQL pour récupérer les données du match
$requete = "SELECT * FROM matchclub WHERE id_match = ?";
$reponse = $bdd->prepare($requete);
$reponse->execute([$matchId]);
$data_match = $reponse->fetch();

// Retourner les données au format JSON
header('Content-Type: application/json');
echo json_encode($data_match);
?>












































  <script>
    var cells = document.querySelectorAll("td[data-id]");

    cells.forEach(function(cell) {
      cell.addEventListener("click", function() {
        var matchId = this.getAttribute("data-id");

        var xhr = new XMLHttpRequest();
        xhr.open('GET','trait.php?id_match=' + matchId, true);

      });
    });
    xhr.onload = function() {
    if (xhr.status === 200) {
      var myDiv = document.getElementById("myDiv");
        myDiv.style.display = "block";

    }}
  </script>






































<style>
  #myDiv {
    display: none;
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
  }
</style>

<div id="myDiv">
  <!-- Votre formulaire de modification ici -->
</div>
