<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Document</title>
</head>
<body>

</body>
</html>















<style>
    /* Style pour la fenêtre popup */
    .modal {
      display: none;
      position: fixed;
      z-index: 1;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      overflow: auto;
      background-color: rgba(0, 0, 0, 0.4);
    }
    
    /* Style pour le contenu de la fenêtre popup */
    .modal-content {
      background-color: #fefefe;
      margin: 10% auto;
      padding: 20px;
      border: 1px solid #888;
      width: 80%;
    }
    
    /* Style pour les boutons de la fenêtre popup */
    .modal-content button {
      margin-top: 10px;
    }
  </style>


































<script>
const cells = document.querySelectorAll('td[data-id]');
cells.forEach(cell => {
  cell.addEventListener('click', () => {
    const id = cell.dataset.id;
    const url = `updateMatch.php?id=${id}`;
    var popup = window.open(${url}, 'popup', 'width=400,height=400');
  })
})
    const modal = document.createElement('div');
    modal.classList.add('modal');
    modal.innerHTML = `
      <h2>Modifier ou supprimer le match</h2>
      <form method="post" action="${url}">
        <label for="equipe1">Équipe 1:</label>
        <input type="text" name="equipe1" id="equipe1" value="">
        <label for="equipe2">Équipe 2:</label>
        <input type="text" name="equipe2" id="equipe2" value="">
        <label for="date">Date:</label>
        <input type="date" name="date" id="date" value="">
        <label for="heure_debut">Heure de début:</label>
        <input type="time" name="heure_debut" id="heure_debut" value="">
        <label for="heure_fin">Heure de fin:</label>`
       






































const modal = document.createElement('div');
modal.classList.add('modal');
modal.innerHTML = `
  <h2>Modifier ou supprimer le match</h2>
  <form method="post" action="${url}">
    <label for="equipe1">Équipe 1:</label>
    <input type="text" name="equipe1" id="equipe1" value="">
    <label for="equipe2">Équipe 2:</label>
    <input type="text" name="equipe2" id="equipe2" value="">
    <label for="date">Date:</label>
    <input type="date" name="date" id="date" value="">
    <label for="heure_debut">Heure de début:</label>
    <input type="time" name="heure_debut" id="heure_debut" value="">
    <label for="heure_fin">Heure de fin:</label>
    <input type="time" name="heure_fin" id="heure_fin" value="">
    <button type="submit" name="action" value="modifier">Modifier</button>
    <button type="submit" name="action" value="supprimer">Supprimer</button>
  </form>
`;

// Ajouter la fenêtre modale au DOM
document.body.appendChild(modal);

// Fermer la fenêtre modale lorsque l'utilisateur clique en dehors de la zone du formulaire
modal.addEventListener('click', e => {
  if (e.target === modal) {
    modal.remove();
  }
});
</script>












var popup = window.open('popup.html', 'popup', 'width=400,height=400');































if(( (!is_null($data['equipe2']))&& (! ($result > 0))&& (!($data1[2] != $data2[0])) )||((is_null($data['equipe2']))&&(!($result1 > 0)))){
                      header("Location: msgAccept.php?id=".$id);
                    }

