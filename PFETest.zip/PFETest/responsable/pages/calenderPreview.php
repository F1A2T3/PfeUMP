<?php
    include "sidebar.php";
    include_once "connection.php";
     $terrain = $_SESSION['id_terrain'];
     $dateCourante = date("Y-m-d");
     $dateSemainePrecedente = date("Y-m-d", strtotime("last week", strtotime($dateCourante)));
     $sql = "SELECT * FROM matchclub WHERE WEEK(temp_debut,1) = WEEK(:date,1) AND WEEK(temp_fin,1) = WEEK(:date,1) AND id_terrain = :terrain AND (statut = 'accept' OR statut = 'fixe')";
     $result = $bdd->prepare($sql);
     $result->execute(array(':date' => $dateSemainePrecedente, ':terrain' => $terrain));
  while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
     $equipe1 = $row['equipe1'];
     if(empty($row['equipe2'])) {
        $equipe2 = ' - ';
      } else {
        $equipe2 = $row['equipe2'];
      }
     $date_debut = date('H:i', strtotime($row['temp_debut']));
     $date_fin = date('H:i', strtotime($row['temp_fin']));
     $dayOfWeek = date('N', strtotime($row['temp_debut']));
     $hour = date('H', strtotime($row['temp_debut']));
     $index = $hour - 8;
     if ($index < 0 || $index > 9) {
         continue;
     }
     $matches[] = array(
        'row' => $index + 1,
        'col' => $dayOfWeek + 1,
        'html' => '<b>' . $equipe1 . '</b> vs <b>' . $equipe2,
     );
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste of user</title>
    <link rel="stylesheet" href="../css/tble.css">
    <link rel="stylesheet" href="../css/nav.css">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/sidebar.css">
    <link rel="stylesheet" href="https://kit.fontawesome.com/6404735ed8.css" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../css/style.css">
    <script src="https://kit.fontawesome.com/6404735ed8.js" crossorigin="anonymous"></script>

     <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
     <link rel="stylesheet" href="../css/style.css">
    <style>
        table {
            border-collapse: collapse;
            width: 75%;
            height: 75%;
        }

        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: center;
        }

        th {
            background-color: #f2f2f2;
        }

        th:first-child, td:first-child {
            text-align: left;
        }

        tbody th {
            background-color: #f2f2f2;
        }

        tbody td {
            color:green;
            background-color: #fff;
        }
    </style> 
</head>

<body>  
  <section id="content">
      <main>
        <ul class="box-info">              
                <li>
                    <i class='' ></i>
                        <span class="text">
                            <?php
                                $aujourdhui = getdate();
                                echo $aujourdhui['month'] . " " . $aujourdhui['year']."\t";
                            ?>
                        </span>
                </li>
                <li style="padding:7px;">
                  <span class="text">
                    <div class="btn col-md-3 "  style="width:1742px;height:34px;background-color: rgb(255,253,44);color: #16774a; border-color :rgb(255,253,44);line-height: 0.5; padding: 0.375rem 0rem;" onclick="window.location.href='Calender.php?id=<?php echo $terrain; ?>'"> La semaine courante  <i class="fa-solid fa-chevron-right" id="fa-icon"></i></div>
                  </span>
                </li>
        </ul>
            <div  class="table-data">
                <div class="order ">

                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th></th>
                                    <th>Lundi<br><?php echo date('d/m/Y', strtotime('monday last week')); ?></th>
                                    <th>Mardi<br><?php echo date('d/m/Y', strtotime('tuesday last week')); ?></th>
                                    <th>Mercredi<br><?php echo date('d/m/Y', strtotime('wednesday last week')); ?></th>
                                    <th>Jeudi<br><?php echo date('d/m/Y', strtotime('thursday last week')); ?></th>
                                    <th>Vendredi<br><?php echo date('d/m/Y', strtotime('friday last week')); ?></th>
                                    <th>Samedi<br><?php echo date ('d/m/Y', strtotime('saturday last week')); ?></th>
                                    <th>Dimanche<br><?php echo date('d/m/Y', strtotime('sunday last week')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <th class="align-middle">8h - 9h</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th class="align-middle">9h - 10h</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th class="align-middle">10h - 11h</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th class="align-middle">11h - 12h</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th class="align-middle">12h - 13h</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th class="align-middle">13h - 14h</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th class="align-middle">14h - 15h</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th class="align-middle">15h - 16h</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th class="align-middle">16h - 17h</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th class="align-middle">17h - 18h</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            </tbody>
                        </table>
                        <script>
                          var matches = <?php echo json_encode($matches); ?>;
                           for (var i = 0; i < matches.length; i++) {
                              var row = matches[i].row;
                              var col = matches[i].col;
                              var html = matches[i].html;
                              document.querySelector('table tbody tr:nth-child(' + row + ') td:nth-child(' + col + ')').innerHTML = html;
                           }
                        </script>
                </div>
            </div>
        </main>
    </section>
    <!-- <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"
        integrity="sha384-+JZJzvJZJzvJzvJZJzvJZJzvJZJzvJZJzvJZJzvJZJzvJZJzvJZJzvJZJzvJZJz"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="../responsable/scripte/script.js"></script> -->
</body>
</html>