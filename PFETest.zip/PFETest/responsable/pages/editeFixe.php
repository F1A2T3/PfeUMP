<?php
   $match = trim($_GET['id']);
   $sql = "SELECT temp_debut,temp_fin FROM matchclub WHERE id_match=:match" ;
   $stmt = $bdd->prepare($sql);
   $stmt->bindParam(':match', $match);
   $stmt->execute();
   $result = $stmt->fetch(PDO::FETCH_ASSOC);

   $temp_debut = $result['temp_debut'];
   $temp_fin = $result['temp_fin'];

   $jourDebut = date("l", strtotime($temp_debut));
   $heureDebut = date("H:i", strtotime($temp_debut));
   $heureFin = date("H:i", strtotime($temp_fin)); 
   $day_en = frenchToEnglishDay($jourDebut);
    echo $day_en;
    $currentMonth = date('n'); 
    $currentYear = date('Y');
    $dayOfWeek = $day_en;
    $dates = array(); 
            if ($currentMonth >= 9) {
                for ($k = $currentMonth; $k <= 12; $k++) {
                    $numDays = date('t', strtotime("$currentYear-$k-01")); 
                        for ($j = 1; $j <= $numDays; $j++) {
                            $date = date('Y-m-d', strtotime("$currentYear-$k-$j"));
                            if (date('l', strtotime($date)) == $dayOfWeek) {
                               $dates[] = $date;
                            }
                        }
                }
                for ($u = 1; $u <= 7; $u++) {
                    $numDays = date('t', strtotime(($currentYear + 1) . "-$u-01")); 
                        for ($j = 1; $j <= $numDays; $j++) {
                            $date = date('Y-m-d', strtotime(($currentYear + 1) . "-$u-$j"));
                            if (date('l', strtotime($date)) == $dayOfWeek) {
                               $dates[] = $date;
                            }
                        }
                }
            } else {
                for ($u = $currentMonth; $u <= 7; $u++) {
                     $numDays = date('t', strtotime("$currentYear-$u-01")); 
                    for ($j = 1; $j <= $numDays; $j++) {
                        $date = date('Y-m-d', strtotime("$currentYear-$u-$j"));
                        if (date('l', strtotime($date)) == $dayOfWeek) {
                            $dates[] = $date;
                        }
                    }
                } 
            }
            print_r($dates);
            $dates_debut = array();
            foreach($dates as $dat) {
               $datetime_str = $dat . ' ' . $heureDebut;
               $datetime = new DateTime($datetime_str);
               $dates_debut[] = $datetime->format('Y-m-d H:i:s');
            }
            $dates_fin = array();
            foreach($dates as $dat) {
               $datetime_str = $dat . ' ' . $heureFin;
               $datetime = new DateTime($datetime_str);
               $dates_fin[] = $datetime->format('Y-m-d H:i:s');
            }
            $ids = array();
            for($m=0;$m<count($dates_debut);$m++){
                $sql = "SELECT id_match FROM matchclub WHERE temp_debut=:debut AND temp_fin=:fin" ;
                $stmt = $bdd->prepare($sql);
                $stmt->bindParam(':debut', $dates_debut[$m]);
                $stmt->bindParam(':fin', $dates_fin[$m]);
                $stmt->execute();
                $result = $stmt->fetch(PDO::FETCH_ASSOC);
                $ids[] = $result['id_match'] ;
            }
            $terrain = $_POST['terrain'];
            $equipe1 = $_POST['equipe1'];
            $equipe2 = $_POST['equipe2'];
            $day = $_POST['day'];
            $heureDebut = $_POST['heure_debut'];
            $heureFin = $_POST['heure_fin'];
            $day_en = frenchToEnglishDay($_POST['day']);
            echo $day_en;
            $currentMonth = date('n'); 
            $currentYear = date('Y');
            $dayOfWeek = $day_en;
            $dates = array(); 
            if ($currentMonth >= 9) {
                for ($k = $currentMonth; $k <= 12; $k++) {
                    $numDays = date('t', strtotime("$currentYear-$k-01")); 
                        for ($j = 1; $j <= $numDays; $j++) {
                            $date = date('Y-m-d', strtotime("$currentYear-$k-$j"));
                            if (date('l', strtotime($date)) == $dayOfWeek) {
                               $dates[] = $date;
                            }
                        }
                }
                for ($u = 1; $u <= 7; $u++) {
                    $numDays = date('t', strtotime(($currentYear + 1) . "-$u-01")); 
                        for ($j = 1; $j <= $numDays; $j++) {
                            $date = date('Y-m-d', strtotime(($currentYear + 1) . "-$u-$j"));
                            if (date('l', strtotime($date)) == $dayOfWeek) {
                               $dates[] = $date;
                            }
                        }
                }
            } else {
                for ($u = $currentMonth; $u <= 7; $u++) {
                     $numDays = date('t', strtotime("$currentYear-$u-01")); 
                    for ($j = 1; $j <= $numDays; $j++) {
                        $date = date('Y-m-d', strtotime("$currentYear-$u-$j"));
                        if (date('l', strtotime($date)) == $dayOfWeek) {
                            $dates[] = $date;
                        }
                    }
                } 
            }
            print_r($dates);
            $dates_debut = array();
            foreach($dates as $dat) {
               $datetime_str = $dat . ' ' . $heureDebut;
               $datetime = new DateTime($datetime_str);
               $dates_debut[] = $datetime->format('Y-m-d H:i:s');
            }
            $dates_fin = array();
            foreach($dates as $dat) {
               $datetime_str = $dat . ' ' . $heureFin;
               $datetime = new DateTime($datetime_str);
               $dates_fin[] = $datetime->format('Y-m-d H:i:s');
            }
            print_r($date_debut);
            print_r($dates_fin);
            $exist=0;
            for($m=0;$m<count($dates_debut);$m++){
                $sql = "SELECT COUNT(*) AS count FROM matchclub WHERE id_mach<>:match AND temp_debut = :debut AND temp_fin = :fin AND id_terrain=:terrain" ;
                $stmt = $bdd->prepare($sql);
                $stmt->bindParam(':match', $ids[$m]);
                $stmt->bindParam(':debut', $dates_debut[$m]);
                $stmt->bindParam(':fin', $dates_fin[$m]);
                $stmt->bindParam(':terrain', $id_terrain);
                $stmt->execute();
                $result = $stmt->fetch(PDO::FETCH_ASSOC);
                $count = $result['count'];
                if($count!=0){
                    $exist=1;
                }
            }
            echo count($dates_debut);
            echo count($dates_fin);
            if($exist==0){
                if(empty($_POST['equipe2'])){
                  for($m=0;$m<count($dates_debut);$m++){
                    $sql = "UPDATE matchclub SET equipe1=:equipe1, equipe2=NULL, id_terrain=:id_terrain, temp_debut=:debut, temp_fin=:fin, statut='accept' where id_match=:match";
                    $stmt = $bdd->prepare($sql);
                    $stmt->bindParam(':equipe1', $equipe1);
                    $stmt->bindParam(':id_terrain', $terrain);
                    $stmt->bindParam(':debut', $dates_debut[$m]);
                    $stmt->bindParam(':fin', $dates_fin[$m]);
                    $stmt->bindParam(':match', $ids[$m]);
                    $stmt->execute();}
                }else{
                    for($m=0;$m<count($dates_debut);$m++){
                        $sql = "UPDATE matchclub SET equipe1=:equipe1, equipe2=:equipe2, id_terrain=:id_terrain, temp_debut=:debut, temp_fin=:fin, statut='accept' where id_match=:match";
                        $stmt = $bdd->prepare($sql);
                        $stmt->bindParam(':equipe1', $equipe1);
                        $stmt->bindParam(':equipe2',$_POST['equipe2']);
                        $stmt->bindParam(':id_terrain', $terrain);
                        $stmt->bindParam(':debut', $dates_debut[$m]);
                        $stmt->bindParam(':fin', $dates_fin[$m]);
                        $stmt->bindParam(':match', $ids[$m]);
                        $stmt->execute();
                    }
                }
            }else{
                if(empty($_POST['equipe2']))
                  $erreur_exist = "Le match fixe que vous avez planifier de l'equipe ".$equipe1." dans ".$_POST['day']."  qui commence ".$date_debut." et qui se termine le ".$date_fin." n'a pas été inséré dans la calendrier, car il existe déjà un autre match prévu pour cette période";
                else{
                  $erreur_exist = "Le match fixe que vous avez planifier entre l'equipe ".$equipe1." et l'equipe".$_POST['equipe2']."dans ".$_POST['day']."  qui commence ".$date_debut." et qui se termine le ".$date_fin." n'a pas été inséré dans la calendrier, car il existe déjà un autre match prévu pour cette période";
                }
                $_SESSION['err_existeEd']=$erreur_exist;
            }
            function frenchToEnglishDay($day) {
                switch($day) {
                  case 'Lundi':
                    return 'Monday';
                  case 'Mardi':
                    return 'Tuesday';
                  case 'Mercredi':
                    return 'Wednesday';
                  case 'Jeudi':
                    return 'Thursday';
                  case 'Vendredi':
                    return 'Friday';
                  case 'Samedi':
                    return 'Saturday';
                  case 'Dimanche':
                    return 'Sunday';
                  default:
                    return '';
                }
              }