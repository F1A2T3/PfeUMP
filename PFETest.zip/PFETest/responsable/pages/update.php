<?php
include 'connection.php';
if(isset($_GET['CIN']))
    $CIN = $_GET['CIN'];
?>