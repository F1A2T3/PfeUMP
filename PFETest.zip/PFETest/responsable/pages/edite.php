<?php
   $action = $_POST['action'];
   if ($action === "modifier") {
      $terrain = $_POST['terrain'];
      $equipe1 = $_POST['equipe1'];
      $equipe2 = $_POST['equipe2'];
      $date = $_POST['date'];
      $heureDebut = $_POST['heure_debut'];
      $heureFin = $_POST['heure_fin'];
      $datestr =  $date . ' ' . $heureDebut;
      $datetime = new DateTime($datestr);
      $debut = $datetime->format('Y-m-d H:i:s');    
      $datestr = $date . ' ' . $heureFin;
      $datetime = new DateTime($datestr);
      $fin = $datetime->format('Y-m-d H:i:s');
      $sql = "SELECT COUNT(*) AS count FROM matchclub WHERE temp_debut = :debut AND temp_fin = :fin";
      $stmt = $bdd->prepare($sql);
      $stmt->bindParam(':debut', $debut);
      $stmt->bindParam(':fin', $fin);
      $stmt->execute();
      $result = $stmt->fetch(PDO::FETCH_ASSOC);
      $count = $result['count'];
      if($count==0){
         $sql = "SELECT COUNT(*) AS count FROM matchclub
         WHERE (equipe1 = :equipe OR equipe2 = :equipe)
         AND YEARWEEK(DATE(:date), 1) = YEARWEEK(DATE(temp_debut), 1) AND statut = :statut";
          $statut="accept";
          $stmt = $bdd->prepare($sql);
          $stmt->bindParam(':equipe', $equipe1);
          $stmt->bindParam(':statut', $statut);
          $stmt->bindParam(':date', $debut);
          $stmt->execute();
          $result = $stmt->fetch(PDO::FETCH_ASSOC);
          $count2 = $result['count'];
          if(empty($_POST['equipe2'])){
             if ($count2 > 0) {
                 $nb_jeu = "Notez bien que l'equipe ".$equipe1." a ".$count2." fois matchs dans la semaine ou la date ".$date." se trouve,vous pouvez vérifier les matchs dans votre calendrier.";
                 $_SESSION['nb_jeu'][$err_jeu]=$nb_jeu;
                }
              $sql = "INSERT INTO matchclub (equipe1, equipe2, id_terrain, temp_debut, temp_fin, statut)
              VALUES (:equipe1, NULL, :id_terrain, :debut, :fin, 'accept')";
              $stmt = $bdd->prepare($sql);
              $stmt->bindParam(':equipe1', $equipe1);
              $stmt->bindParam(':id_terrain', $id_terrain);
              $stmt->bindParam(':debut', $debut);
              $stmt->bindParam(':fin', $fin);
              $stmt->execute();
           }else{
              $sql = "SELECT COUNT(*) AS count FROM matchclub
              WHERE (equipe1 = :equipe OR equipe2 = :equipe)
              AND YEARWEEK(DATE(:date), 1) = YEARWEEK(DATE(temp_debut), 1) AND statut = :statut";
              $statut="accept";
              $stmt = $bdd->prepare($sql);
              $stmt->bindParam(':equipe',$_POST['equipe2']);
              $stmt->bindParam(':statut', $statut);
              $stmt->bindParam(':date', $debut);
              $stmt->execute();
              $result = $stmt->fetch(PDO::FETCH_ASSOC);
              $count3 = $result['count'];
              $count4=$count2+$count3;
              if($count4>0){
                 $nb_jeu = "Notez bien que l'equipe ".$equipe1."et l'equipe ".$_POST['equipe2'][$i]." ont ".$count4." fois matchs dans la semaine ou la date ".$date." se trouve,vous pouvez vérifier les matchs dans votre calendrier.";
                 $_SESSION['nb_jeu'][$err_jeu]=$nb_jeu;
                }
                $sql = "INSERT INTO matchclub (equipe1, equipe2, id_terrain, temp_debut, temp_fin, statut)
                VALUES (:equipe1, :equipe2, :id_terrain, :debut, :fin, 'accept')";
                 $stmt = $bdd->prepare($sql);
                $stmt->bindParam(':equipe1', $equipe1);
                $stmt->bindParam(':equipe2', $_POST['equipe2'][$i]);
                $stmt->bindParam(':id_terrain', $id_terrain);
                $stmt->bindParam(':debut', $debut);
                $stmt->bindParam(':fin', $fin);
                $stmt->execute();
            }   
        }
        else{
           if(empty($_POST['equipe2'][$i]))
              $erreur_exist = "Le match que vous avez planifier de l'equipe ".$equipe1." dans ".$date ."  qui commence ".$date_debut." et qui se termine le ".$date_fin." n'a pas été inséré dans la calendrier, car il existe déjà un autre match prévu pour cette période";
            else{
               $erreur_exist = "Le match que vous avez planifier entre l'equipe ".$equipe1." et l'equipe".$_POST['equipe2'][$i]."dans ".$date ."  qui commence ".$date_debut." et qui se termine le ".$date_fin." n'a pas été inséré dans la calendrier, car il existe déjà un autre match prévu pour cette période";
            }
              $_SESSION['err_existe'][$err_existe]=$erreur_exist;
        }
    }
   else{



   }