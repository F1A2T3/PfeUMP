<?php
   $day = $_POST['day'];
   $day_en = frenchToEnglishDay($day);
   
   $date = date("Y-m-d", strtotime($day_en));
   $terrain = $_POST['terrain'];
   $equipe1 = $_POST['equipe1'];
   $equipe2 = $_POST['equipe2'];
   $heureDebut = $_POST['heure_debut'];
   $heureFin = $_POST['heure_fin'];
   $match=$_SESSION['id_matchUp'];
   $datestr =  $date . ' ' . $heureDebut;
   $datetime = new DateTime($datestr);
   $debut = $datetime->format('Y-m-d H:i:s');    
   $datestr = $date . ' ' . $heureFin;
   $datetime = new DateTime($datestr);
   $fin = $datetime->format('Y-m-d H:i:s');
   $sql = "SELECT COUNT(*) AS count FROM matchclub WHERE id_match<>:match AND temp_debut = :debut AND temp_fin = :fin AND id_terrain=:terrain" ;
   $stmt = $bdd->prepare($sql);
   $stmt->bindParam(':debut', $debut);
   $stmt->bindParam(':fin', $fin);
   $stmt->bindParam(':match', $match);
   $stmt->bindParam(':terrain', $terrain);
   $stmt->execute();
   $result = $stmt->fetch(PDO::FETCH_ASSOC);
   $count = $result['count'];
   if($count==0){
       $sql = "SELECT COUNT(*) AS count FROM matchclub
       WHERE id_match<>:match AND (equipe1 = :equipe OR equipe2 = :equipe)
       AND YEARWEEK(DATE(:date), 1) = YEARWEEK(DATE(temp_debut), 1) AND statut = :statut AND id_terrain=:terrain";
       $statut="accept";
       $stmt = $bdd->prepare($sql);
       $stmt->bindParam(':equipe', $equipe1);
       $stmt->bindParam(':statut', $statut);
       $stmt->bindParam(':match', $match);
       $stmt->bindParam(':date', $debut);
       $stmt->bindParam(':terrain', $terrain);
       $stmt->execute();
       $result = $stmt->fetch(PDO::FETCH_ASSOC);
       $count2 = $result['count'];
       if(empty($equipe2)){
          if ($count2 > 0) {
              $nb_jeu = "Notez bien que l'equipe ".$equipe1." a ".$count2." fois matchs dans la semaine ou la date ".$date." se trouve,vous pouvez vérifier les matchs dans votre calendrier.";
              $_SESSION['nb_jeuEd']=$nb_jeu;
             }
           $sql = "UPDATE matchclub SET equipe1=:equipe1, equipe2=NULL, id_terrain=:id_terrain, temp_debut=:debut, temp_fin=:fin, statut='accept' where id_match=:match";
           $stmt = $bdd->prepare($sql);
           $stmt->bindParam(':equipe1', $equipe1);
           $stmt->bindParam(':id_terrain', $terrain);
           $stmt->bindParam(':debut', $debut);
           $stmt->bindParam(':fin', $fin);
           $stmt->bindParam(':match', $match);
           $stmt->execute();
        }else{
           $sql = "SELECT COUNT(*) AS count FROM matchclub
           WHERE id_match<>:match AND (equipe1 = :equipe OR equipe2 = :equipe)
           AND YEARWEEK(DATE(:date), 1) = YEARWEEK(DATE(temp_debut), 1) AND statut = :statut AND id_terrain=:terrain";
           $statut="accept";
           $stmt = $bdd->prepare($sql);
           $stmt->bindParam(':equipe',$equipe2);
           $stmt->bindParam(':statut', $statut);
           $stmt->bindParam(':date', $debut);
           $stmt->bindParam(':match', $match);
           $stmt->bindParam(':terrain', $terrain);
           $stmt->execute();
           $result = $stmt->fetch(PDO::FETCH_ASSOC);
           $count3 = $result['count'];
           $count4=$count2+$count3;
           if($count4>0){
              $nb_jeu = "Notez bien que l'equipe ".$equipe1."ou l'equipe ".$_POST['equipe2']." ont ".$count4." fois matchs dans la semaine ou la date ".$date." se trouve,vous pouvez vérifier les matchs dans votre calendrier.";
              $_SESSION['nb_jeuEd']=$nb_jeu;
             }
             $sql =  "UPDATE matchclub SET equipe1=:equipe1, equipe2=:equipe2, id_terrain=:id_terrain, temp_debut=:debut, temp_fin=:fin, statut='accept'where id_match=:match";
              $stmt = $bdd->prepare($sql);
             $stmt->bindParam(':equipe1', $equipe1);
             $stmt->bindParam(':equipe2', $equipe2);
             $stmt->bindParam(':id_terrain', $terrain);
             $stmt->bindParam(':debut', $debut);
             $stmt->bindParam(':fin', $fin);
             $stmt->bindParam(':match', $match);
             $stmt->execute();
         }   
     }
     else{
        if(empty($equipe2))
           $erreur_exist = "Le match que vous avez planifier de l'equipe ".$equipe1." dans ".$date ."  qui commence ".$heureDebut." et qui se termine le ".$heureFin." n'a pas été inséré dans la calendrier, car il existe déjà un autre match prévu pour cette période";
         else{
            $erreur_exist = "Le match que vous avez planifier entre l'equipe ".$equipe1." et l'equipe".$equipe2."dans ".$date ."  qui commence ".$heureDebut." et qui se termine le ".$heureFin." n'a pas été inséré dans la calendrier, car il existe déjà un autre match prévu pour cette période";
         }
           $_SESSION['err_existeEd']=$erreur_exist;
     }
     function frenchToEnglishDay($day) {
        switch($day) {
          case 'Lundi':
            return 'Monday';
          case 'Mardi':
            return 'Tuesday';
          case 'Mercredi':
            return 'Wednesday';
          case 'Jeudi':
            return 'Thursday';
          case 'Vendredi':
            return 'Friday';
          case 'Samedi':
            return 'Saturday';
          case 'Dimanche':
            return 'Sunday';
          default:
            return '';
        }
      }