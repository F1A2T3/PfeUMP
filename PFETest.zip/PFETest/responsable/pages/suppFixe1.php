<?php
    $match=$_SESSION['id_matchUp'];
    $sql =  "DELETE from matchClub where id_match=:match";
    $stmt = $bdd->prepare($sql);
    $stmt->bindParam(':match', $match);
    $stmt->execute();