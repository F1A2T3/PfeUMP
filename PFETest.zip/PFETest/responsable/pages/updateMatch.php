<?php
  require_once 'connection.php';
  if(isset($_SESSION['id_matchUp'])){
    $requete = "SELECT * FROM matchclub WHERE id_match = ?";
    $reponse = $bdd->prepare($requete);
    $reponse->execute([$match]);
    $data_match = $reponse->fetch();
 
    $terrain_match=$data_match['id_terrain'];
    $equipe1_match=$data_match['equipe1'];
    $date_match=date("Y-m-d", strtotime($data_match['temp_debut']));
    $debut_time=date("H:i:s", strtotime($data_match['temp_debut']));
    $fin_time=date("H:i:s", strtotime($data_match['temp_fin']));
    $etat_match=$data_match['statut'];

    if($etat_match=="fixe"){
     $d= date("N", strtotime($date_match));
    }
  }
?>



<style>
  #formulaires {
    display: none;
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background-color:red;
  }
</style>



























<link rel="stylesheet" href="../css/match.css">
<div id="formulaires">
  <form action="RespoReservation.php" method="POST" id="contact_form" style="width:561px;">
     <div class="name">
        <label for="terrain">TERRAIN</label>
          <select name="terrain" required>
             <option value="1"<?php if($terrain_match==1){echo "selected";} ?>>Terrain de foot</option>
             <option value="2"<?php if($terrain_match==2){echo "selected";} ?>>Terrain de basket</option>
             <option value="3"<?php if($terrain_match==3){echo "selected";} ?>>Terrain de volley</option>
          </select><br>
      </div><br><br><br><br><br>
     <div class="name">
        <label for="equipe1">EQUIPE 1 :</label>
          <select name="equipe1" required>
            <?php 
              $sql = "SELECT Nom_equipe,nbr_joueurs FROM equipe";
              $stmt = $bdd->prepare($sql);
              $stmt->execute();
              while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                if($row['nbr_joueurs']>0){
                  if($equipe1_match==$row['Nom_equipe']){
                    echo "<option value=\"$row[Nom_equipe]\" selected>";
                  }
                  else{
                    echo "<option value=\"$row[Nom_equipe]\">";
                  }
                  echo  $row['Nom_equipe'] . "<br>";
                  echo "</option>";
                }
              } 
            ?>
          </select><br>
      </div><br><br><br><br><br>
      <div class="email">
        <label for="equipe2">EQUIPE 2 :</label>
          <select name="equipe2">
            <?php
              if(is_null($data_match['equipe2'])){
            ?>
              <Option selected></Option>
            <?php
             }else{
            ?>
              <option></option> 
            <?php
             }
            ?>
            <?php 
              $sql = "SELECT Nom_equipe,nbr_joueurs FROM equipe";
              $stmt = $bdd->prepare($sql);
              $stmt->execute();
              while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                if($row['nbr_joueurs']>0){
                  if(!is_null($data_match['equipe2'])){
                    if($row['Nom_equipe']==$data_match['equipe2'])
                     echo "<option value=\"$row[Nom_equipe]\" selected>";
                    else
                     echo "<option value=\"$row[Nom_equipe]\">";
                  }else{
                   echo "<option value=\"$row[Nom_equipe]\">";
                  }
                   echo  $row['Nom_equipe'] . "<br>";
                   echo "</option>";}
              } 
            ?>
          </select><br>
      </div><br><br><br><br><br>
      <div class="date">
       <?php
         if($etat_match=="fixe"){
       ?>
        <p style="padding-top: 20px; padding-left: 30px;"><em>Ce match est fixe tout au long de l'année :</em></p>
          <div id="content">
            <select id="chEq" name="day">
              <option value="Lundi" <?php if($d==1){ echo "selected"; } ?>>Lundi</option>
              <option value="Mardi" <?php if($d==2){ echo "selected"; } ?>>Mardi</option>
              <option value="Mercredi" <?php if($d==3){ echo "selected"; } ?>>Mercredi</option>
              <option value="Jeudi" <?php if($d==4){ echo "selected"; } ?>>Jeudi</option>
              <option value="Vendredi" <?php if($d==5){ echo "selected"; } ?>>Vendredi</option>
              <option value="Samedi" <?php if($d==6){ echo "selected"; } ?>>Samedi</option>
              <option value="Dimanche" <?php if($d==7){ echo "selected"; } ?>>Dimanche</option>
            </select>
       <?php  }else{ 
        ?>
          <div class="input-group">
           <p style="padding-top: 20px; padding-left: 30px;"><em>La date du match :</em></p>
            <input class="datepicker-input" type="date" name="date" placeholder="date :" id="crEq" value="<?= $date_match ?>">
          </div>
          <?php } ?>
          </div><br><br><br>
          <label for="date_debut"> Heure début :</label>
          <input type="time" name="heure_debut" id="date_debut_input" required value="<?= $debut_time ?>"><br>
        </div><br>
        <div class="date">
          <label for="date_fin"> Heure fin :</label>
          <input type="time" name="heure_fin" id="date_fin_input" required value="<?= $fin_time ?>">
         </div>
       <br><br>
       <button class="submit" type="button" onclick="ajouterFormulaire()" id="form_button">Modifier</button>
       <button class="submit" type="submit" id="form_button">Supprimer</button>
  </form>
</div>















<script>
   $(function () {
      $('#datepicker').datepicker({
        format: 'yyyy-mm-dd',
        autoclose: true,
        todayHighlight: true,
      });
   });
</script>













<script>
    var cells = document.querySelectorAll("td[data-id]");

    cells.forEach(function(cell) {
      cell.addEventListener("click", function() {
        var matchId = this.getAttribute("data-id");

        var xhr = new XMLHttpRequest();
        xhr.open('GET','trait.php?id_match=' + matchId, true);


        xhr.onload = function() {
        if (xhr.status === 200) {
         var myDiv = document.getElementById("myDiv");
         myDiv.style.display = "block";
        }}

        xhr.send();
      });
    });
</script>