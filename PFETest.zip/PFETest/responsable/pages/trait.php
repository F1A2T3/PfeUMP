<?php
   session_start();
   $id_match=$_GET['id_match'];
   unset($_SESSION['id_matchUp']);
   $_SESSION['id_matchUp']=$id_match;
   echo $_SESSION['id_matchUp'];
   //header("Location: updateMatch.php");
?>