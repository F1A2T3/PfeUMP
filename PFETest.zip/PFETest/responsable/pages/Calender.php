<?php
    include "sidebar.php";
    include_once "connection.php";
    //unset($_SESSION['id_matchUp']);
     $terrain = trim($_GET['id']);
     $_SESSION['id_terrain'] = $terrain; 
     //Reservation erreur
    if(isset($_SESSION['err_existe'])  && !empty($_SESSION['err_existe'])){
        $message = '   Erreur d\'ajout :  ';
        foreach($_SESSION['err_existe'] as $key => $value) {
          $message .= '-->'. $value . '\n';
        }
        echo '<script>alert("'.$message.'");</script>';
        unset($_SESSION['err_existe']);
    }
    if(isset($_SESSION['nb_jeu']) && !empty($_SESSION['nb_jeu'])) {
        $message = '   Erreur d\'ajout :  ';
        foreach($_SESSION['nb_jeu'] as $key => $value) {
          $message .= '-->'. $value . '\n';
        }
        echo '<script>alert("'.$message.'");</script>';
        unset($_SESSION['nb_jeu']);
    }
    if(isset($_SESSION['err_existeEd'])  && !empty($_SESSION['err_existeEd'])){
       $message = '   Erreur de modification :  ';
       $message .= '-->'. $_SESSION['err_existeEd'] . '\n';
       ?><script>
           var message= <?= json_encode($message) ?> ;
           alert(message);
          </script>
       <?php
       unset($_SESSION['err_existeEd']);
     }
     if(isset($_SESSION['nb_jeuEd']) && !empty($_SESSION['nb_jeuEd'])){
      $message = '   Erreur de modification :  ';
      $message .= '-->'. $_SESSION['nb_jeuEd'] . '\n';
      echo '<script>alert("'.$message.'");</script>';
      unset($_SESSION['nb_jeuEd']);
     }
     $sql = "SELECT * FROM matchclub WHERE WEEK(temp_debut,1) = WEEK(NOW(),1) AND WEEK(temp_fin,1) = WEEK(NOW(),1) AND id_terrain = $terrain And (statut = 'accept' OR statut = 'fixe')";
     $result = $bdd->query($sql);
  while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
     $equipe1 = $row['equipe1'];
     if(empty($row['equipe2'])) {
        $equipe2 = " - ";
      } else {
        $equipe2 = $row['equipe2'];
      }
     $id = $row['id_match'];
     $date_debut = date('H:i', strtotime($row['temp_debut']));
     $date_fin = date('H:i', strtotime($row['temp_fin']));
     $dayOfWeek = date('N', strtotime($row['temp_debut']));
     $hour = date('H', strtotime($row['temp_debut']));
     $index = $hour - 8;
     if ($index < 0 || $index > 9) {
         continue;
     }
     $matches[] = array(
        'row' => $index + 1,
        'col' => $dayOfWeek + 1,
        'html' => '<b>' . $equipe1 . '</b> vs <b>' . $equipe2 . '</b>' ,
        'id' => $id,
     );
    }
?>
<script>window.onload = loadTableData;</script>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste of user</title>
    <link rel="stylesheet" href="../css/tble.css">
    <link rel="stylesheet" href="../css/nav.css">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/sidebar.css">
    <link rel="stylesheet" href="https://kit.fontawesome.com/6404735ed8.css" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../css/style.css">
    <script src="https://kit.fontawesome.com/6404735ed8.js" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
     <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
     <link rel="stylesheet" href="../css/style.css">
     <link rel="stylesheet" href="../css/match.css">
    <style>
        table {
            border-collapse: collapse;
            width: 75%;
            height: 75%;
        }

        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: center;
        }

        th {
            background-color: #f2f2f2;
        }

        th:first-child, td:first-child {
            text-align: left;
        }

        tbody th {
            background-color: #f2f2f2;
        }

        tbody td {
            background-color: #fff;
            color:green;
        }
        #formulaires {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
            z-index: 9999;
            opacity: 1;
            transition: opacity 0.3s ease;
        }
        .transparent-effect {
             opacity: 0.5; /* Opacité des autres éléments */
             filter: blur(5px); /* Flou des autres éléments */
             transition: opacity 0.3s ease, filter 0.3s ease;
           }

    </style> 
</head>

<body>  
  <section id="content">
  <main style="margin-top: 60px;background-color:rgb(225, 253, 44);">            
            <ul class="box-info">
              <li style="padding:7px;">
                  <span class="text">
                    <div class="btn col-md-3 "  style="width:1069px;height:34px;background-color: rgb(255,253,44);color: #16774a; border-color :rgb(255,253,44);line-height: 0.5; padding: 0.375rem 0rem;" onclick="window.location.href='calenderPreview.php'"> <i class="fa-solid fa-chevron-left" id="fa-icon"></i> La semaine précédente  </div>
                  </span>
                </li>
                <li style="padding:7px;">
                    <span class="text" style="margin:-4px;">
                        <?php
                            $aujourdhui = getdate();
                            echo $aujourdhui['mday'] . " " . $aujourdhui['month'] . " " . $aujourdhui['year'] ."\t";
                        ?>
                    </span>
                   <button class="button-7 bx" role="button" style="width:166px;height:46px;background-color:rgb(225, 253, 44) ; border-color :rgb(225, 253, 44); text-align:center;" onclick="window.location.href='calenderReserv.php'"><p style="font-size:23px;color:#16774a;"> Ajouter Match</p></button>
                </li>
                 <li style="padding:7px;">
                  <span class="text">
                    <div class="btn col-md-3 "  style="width:1069px;height:34px;background-color: rgb(255,253,44);color: #16774a; border-color :rgb(255,253,44);line-height: 0.5; padding: 0.375rem 0rem;" onclick="window.location.href='calenderNext.php'"> La semaine prochaine  <i class="fa-solid fa-chevron-right" id="fa-icon"></i></div>
                  </span>
                </li>
            </ul> <br> 
            <div  class="table-data">
                <div class="order ">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th></th>
                                    <th>Lundi<br><?php echo date('d/m/Y', strtotime('monday this week')); ?></th>
                                    <th>Mardi<br><?php echo date('d/m/Y', strtotime('tuesday this week')); ?></th>
                                    <th>Mercredi<br><?php echo date('d/m/Y', strtotime('wednesday this week')); ?></th>
                                    <th>Jeudi<br><?php echo date('d/m/Y', strtotime('thursday this week')); ?></th>
                                    <th>Vendredi<br><?php echo date('d/m/Y', strtotime('friday this week')); ?></th>
                                    <th>Samedi<br><?php echo date ('d/m/Y', strtotime('saturday this week')); ?></th>
                                    <th>Dimanche<br><?php echo date('d/m/Y', strtotime('sunday this week')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <th class="align-middle">8h - 9h</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th class="align-middle">9h - 10h</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th class="align-middle">10h - 11h</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th class="align-middle">11h - 12h</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th class="align-middle">12h - 13h</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th class="align-middle">13h - 14h</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th class="align-middle">14h - 15h</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th class="align-middle">15h - 16h</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th class="align-middle">16h - 17h</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th class="align-middle">17h - 18h</th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            </tbody>
                        </table>
                        <script>
                          var matches = <?php echo json_encode($matches); ?>;
                            for (var i = 0; i < matches.length; i++) {
                              var row = matches[i].row;
                              var col = matches[i].col;
                              var html = matches[i].html;
                              var id = matches[i].id;
                              var td = document.querySelector('table tbody tr:nth-child(' + row + ') td:nth-child(' + col + ')');
                              td.innerHTML = html;
                              td.setAttribute('data-id', id);
                            }
                            var cells = document.querySelectorAll("td[data-id]");

                            cells.forEach(function(cell) {
                              cell.addEventListener("click", function() {
                                var matchId = this.getAttribute("data-id");
                                window.location.href = "modifMatch.php?matchId=" + matchId;
                              //   var xhr = new XMLHttpRequest();
                              //   xhr.open('GET','trait.php?id_match=' + matchId, true);

                              //    xhr.onload = function() {
                              //      if (xhr.status === 200) {
                              //         var response = xhr.responseText;
                              //         console.log(response);
                              //         var data = JSON.parse(response); 

                              //         var terrainMatch = data.terrain_match;
                              //         var equipe1Match = data.equipe1_match;
                              //         var equipe2 = data.equipe2;
                              //         var dateMatch = data.date_match;
                              //         var debutTime = data.debut_time;
                              //         var finTime = data.fin_time;
                              //         var etatMatch = data.etat_match;
                              //         var d = data.d;
                              //         var selectElement = document.querySelector('select[name="terrain"]');
                              //         for (var i = 0; i < selectElement.options.length; i++) {
                              //            var option = selectElement.options[i];
                              //            if (option.value === terrainMatch) {
                              //              option.selected = true;
                              //            }
                              //         }
                              //         var selectElement = document.querySelector('select[name="equipe1"]');
                              //         for (var i = 0; i < selectElement.options.length; i++) {
                              //            var option = selectElement.options[i];
                              //            if (option.value === equipe1Match) {
                              //               option.selected = true;
                              //             }
                              //         }
                              //         var selectElement = document.querySelector('select[name="equipe2"]');
                              //         for (var i = 0; i < selectElement.options.length; i++) {
                              //           var option = selectElement.options[i];
                              //           if (equipe2 === null || equipe2 === '') {
                              //            option.selected = true;
                              //            break;
                              //           } else if (option.value === equipe2) {
                              //            option.selected = true;
                              //           }
                              //         }
                              //         var contentDiv = document.getElementById('content');
                              //         var inputGroupDiv = document.querySelector('.input-group');
                              //         if (etatMatch != "fixe") {
                              //           contentDiv.style.display = 'none';
                              //           inputGroupDiv.style.display = 'block';
                              //           var inputElement = document.getElementById('crEq');
                              //           inputElement.value = dateMatch;
                              //         } else {
                              //          contentDiv.style.display = 'block';
                              //          inputGroupDiv.style.display = 'none';
                              //          var selectElement = document.getElementById('chEq');
                              //          for (var i = 0; i < selectElement.options.length; i++) {
                              //          var option = selectElement.options[i];
                              //          if ((i+1) == d) {
                              //            option.selected = true;
                              //            break;
                              //           }
                              //         }
                              //         }
                              //         var inputElement = document.getElementById('date_debut_input');
                              //         inputElement.value = debutTime;
                              //         var inputElement = document.getElementById('date_fin_input');
                              //         inputElement.value = finTime;
                              //         var myDiv = document.getElementById("formulaires");
                              //         myDiv.style.display = "block"; 
                              //         var elements = document.querySelectorAll('body > *:not(#formulaires)');
                              //         for (var i = 0; i < elements.length; i++) {
                              //             elements[i].classList.add('transparent-effect');
                              //          } 
                              //       }
                              //     }
                              //     xhr.send();
                               });
                           });
                        </script>
                </div>
            </div>
        </main>
    </section>
    <!-- <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"
        integrity="sha384-+JZJzvJZJzvJzvJZJzvJZJzvJZJzvJZJzvJZJzvJZJzvJZJzvJZJzvJZJzvJZJz"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="../responsable/scripte/script.js"></script> -->
</body>
</html>